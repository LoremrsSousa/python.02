num1 = int(input("digite um n1: "))
num2 = int(input("digite um n2: "))

if num1 == num2:
    print("são iguais")
else:
    print("diferentes")