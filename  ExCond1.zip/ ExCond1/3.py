num = int(input("digite um numero: "))

if num %2 == 0:
    print("par")
else:
    print('impar')