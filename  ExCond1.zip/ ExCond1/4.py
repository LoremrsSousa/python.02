idadenas = int(input("digite seu ano de nascimento: "))

idade = (2023 - idadenas)
if idade > 18:
    print('ele é maior de idade')
else:
    print('menor de idade')

