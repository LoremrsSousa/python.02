num1 = float(input("Digite a N1: "))
num2 = float(input("Digite a N2: "))

if num1 > num2:
     print("numero 1 é maior")
elif num2 > num1:
    print("numero 2 é maior")
else:
    print("são iguais")
