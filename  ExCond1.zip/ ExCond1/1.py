nota1 = float(input("Digite a N1: "))
nota2 = float(input("Digite a N2: "))

media = (nota1 + nota2)/2
if media >= 6:
     print("aprovado")
else:
 print("reprovado")