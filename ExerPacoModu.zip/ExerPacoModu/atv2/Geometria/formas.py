def area_circulo(raio):
    pi = 3.14
    area = pi * raio ** 2
    return area

def area_quadrado(lado):
    area = lado ** 2
    return area