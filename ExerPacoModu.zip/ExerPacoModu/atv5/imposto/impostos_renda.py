def calcular_imposto_renda(salario):
    imposto = salario * 0.15
    return imposto

def calcular_icms(valor_produto):
    icms = valor_produto * 0.10
    return icms