def fahrenheit(celsius):
        fahrenheit = celsius * 9/5 + 32
        return fahrenheit

def celsius(fahrenheit):
        celsius = (fahrenheit - 32) * 5/9
        return celsius
