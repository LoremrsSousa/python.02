import random

def jogo_adivinhar():
    numero = random.randint(1, 100)
    tentativa = 0
    return numero