
while True:
    pessoa = str(input(" Digite seu sexo M/F: "))
    if not pessoa == 'M' or pessoa == 'F':
        break
    else:
      print('DIGITE NOVAMENTE!')
