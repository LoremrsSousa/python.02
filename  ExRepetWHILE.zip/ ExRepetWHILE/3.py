while True:
    numero = int(input('Digite um número: '))
    if numero < 0:
     break
    elif numero == 999:
        break
