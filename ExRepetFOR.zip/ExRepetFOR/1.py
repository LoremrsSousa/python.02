pares = 0
for num in range(1,101):
    if num % 2 == 0:
        pares += 1
        print(num)
print("tem: ", pares)