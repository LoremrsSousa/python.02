time1 = int(input("Digite quantos gols o time 1 fez: "))
time2 = int(input("Digite quantos gols o time 2 fez: "))

if time1 > time2:
    print("time 1 ganhou!")
elif time2 > time1:
    print("time 2 ganhou!!")
else:
    print("deu empate")