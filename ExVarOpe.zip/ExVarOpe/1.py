nota1 = int(input('digite a N1: '))
nota2 = int(input('digite o N2: '))
nota3 = int(input('digite o N3: '))
media = (nota1 + nota2 + nota3) /3
print(" a média do aluno é de: " , media)