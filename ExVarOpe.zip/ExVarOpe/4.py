raio = int(input('digite a base: '))
altura = int(input('digite a altura: '))
PI = 3.14
volume = PI * (raio** 2) * altura
print("o volume é: " , volume)