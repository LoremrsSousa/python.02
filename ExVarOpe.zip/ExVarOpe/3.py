salario = float(input("ADICIONE SEU SALARIO: "))
porcentual = float(input("ADICIONE O PORCENTUAL DE AUMENTO: "))
salarioat =((salario *  porcentual)/100) + salario
print("o valor do salario atual é: " , salarioat)
