cateto1= 4
cateto2 =3
hipotenusa = ((cateto1** 2) + (cateto2** 2))**2
print(hipotenusa)