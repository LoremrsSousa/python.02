amigos = ('Ana', ' Lorena', 'Laura', 'Julia' , 'Fer')
idade =  (17 , 16 , 18 ,20 , 23)
for C in range (0,6):
    print(amigos[C],'a idade é ', idade[C])