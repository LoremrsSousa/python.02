numero1  = int(input("Adicione o numero do pedido:  "))
itens1  = input("Adicione seu pedido: ")
valor1  = float(input("Adicione o valor do pedido:  "))

tup = ( numero1, itens1 , valor1)
print(tup)


numero2  = int(input("Adicione o numero do pedido:  "))
itens2  = input("Adicione seu pedido: ")
valor2  = float(input("Adicione o valor do pedido:  "))

tua = ( numero2, itens2 , valor2)
print(tua)


numero3  = int(input("Adicione o numero do pedido:  "))
itens3  = input("Adicione seu pedido: ")
valor3  = float(input("Adicione o valor do pedido:  "))

tuf = ( numero3, itens3 , valor3)
print(tuf)
