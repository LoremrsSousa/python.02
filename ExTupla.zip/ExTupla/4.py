contato1 = "julia", "16 988737183", "juliagarcia@gmail.com"
contato2 = "pedro", "18 988794873", "pedrolopes@gmail.com"
contato3 = "Laura", "18 988739865", "Lauramendes@gmail.com"

print("Contato 1 ")
print("Nome:", contato1[0])
print("Telefone:", contato1[1])
print("Email:", contato1[2])

print("Contato 2")
print("Nome:", contato2[0])
print("Telefone:", contato2[1])
print("Email:", contato2[2])

print("Contato 3 ")
print("Nome:", contato3[0])
print("Telefone:", contato3[1])
print("Email:", contato3[2])