produto1 = "Arroz", "33", "R$12,00"
produto2 = "Feijão", "22", "R$13,00"
produto3 = "Farinha", "18", "R$10,00"
produto4 = "Farofa", "20", "R$12,99"

print("Estoque 1 ")
print("Nome:", produto1[0])
print("Quantidade:", produto1[1])
print("Preço:", produto1[2])

print("Estoque 2 ")
print("Nome:", produto2[0])
print("Quantidade:", produto2[1])
print("Preço:", produto2[2])

print("Estoque 3 ")
print("Nome:", produto3[0])
print("Quantidade:", produto3[1])
print("Preço:", produto3[2])

print("Estoque 4 ")
print("Nome:", produto4[0])
print("Quantidade:", produto4[1])
print("Preço:", produto4[2])