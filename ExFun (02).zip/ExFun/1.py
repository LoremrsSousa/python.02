from modulo import LarguraeComprimento
largura = int(input('Digite a largura: '))
comprimento = int(input('Digite a comprimento: '))
LarguraeComprimento(largura,comprimento)