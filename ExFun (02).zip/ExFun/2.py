from modulo import escreva
texto = str(input('digite um texto: '))
escreva(texto)
