#1
def LarguraeComprimento(a,b):
    area = a * b
    print('o valor da area é: ', area)
