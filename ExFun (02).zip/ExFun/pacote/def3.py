#3
def maior(valores):
    b = max(valores)
    print(f'O maior número é: {b}')

