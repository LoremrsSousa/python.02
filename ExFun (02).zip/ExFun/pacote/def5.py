#5
def ficha(nome =  '', gols = 0 ):
    print(f'o jogador{nome} marcou {gols}. ')