#2
def  escreva(txt):
    print('- ' * len(txt))
    print(txt)
    print('- ' * len(txt))
