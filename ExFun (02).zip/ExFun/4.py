from modulo import voto
AnoN = int(input('Digite seu ano de nascimento: '))
AnoA = 2023
voto (AnoA, AnoN)