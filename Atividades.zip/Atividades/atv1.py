nome = str(input("Digite seu nome: "))
idade = int(input("Digite sua idade: "))
print(f"seu nome é {nome} e sua idade é {idade}")