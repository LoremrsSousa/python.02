num =[]
for n in range(5):
    nume = int(input("Digite um número para inserir na lista!: "))
    num.append(nume)

print(num)