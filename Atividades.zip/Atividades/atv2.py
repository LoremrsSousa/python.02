lado = int(input("Digite o lado do retângulo: "))
base = int(input("Digite a base do retângulo: "))
area = lado*base
print(f"A area do retângulo é {area}")