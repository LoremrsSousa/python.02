num =  int(input("Digite um número inteiro: "))

if num > 0:
    print("O número é positivo")
elif num < 0 :
    print("O número é negativo")
else:
    print("O número é igual a 0")