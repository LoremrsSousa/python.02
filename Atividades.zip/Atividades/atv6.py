fruta = ('Maça', 'Banana','Abacaxi')
inf = str(input("Informe uma Fruta: "))
if inf in fruta:
    print("Fruta encontrada!")
else:
    print("Fruta não encontrada")