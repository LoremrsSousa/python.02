def num(a):
    if a %2 == 0:
        print("É PAR")
    else:
        print("É IMPAR")


valor = int(input("Digite um número:  "))
num(valor)