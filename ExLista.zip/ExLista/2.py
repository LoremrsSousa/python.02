
lista = []
for i in range(5):
    num = int(input("Digite um número:  "))
    lista.append(num)
lista.sort()
print("Lista:", lista)