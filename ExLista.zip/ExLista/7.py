lista =  list()
opcao = ' '

while True:
    n = int(input('Digite um valor: '))
    if n not in lista:
        lista.append(n)
        print('Valor adicionado com sucesso...')
    else:
        print('Valor duplicado! Não vou adicionar...')
    opcao = str(input('Quer continuar ? [S/N] '))
    if opcao in 'Nn':
        break

lista.sort()
print(f'Você digitou: {lista}')