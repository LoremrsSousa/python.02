numero = int(input('digite um numero inteiro: '))
print(numero + 1)
print(numero - 1)