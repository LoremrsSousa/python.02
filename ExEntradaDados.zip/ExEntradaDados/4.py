base = int(input('digite a base: '))
altura = int(input('digite a altura: '))
print( "a area do retangulo é: " , base * altura)
print(" o perimetro é: ", base + base + altura + altura)