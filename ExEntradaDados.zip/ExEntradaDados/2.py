caractere1= input("Adicione um texto1: ")
caractere2= input("Adicione um text2: ")
print ("o usuario digitou os seguintes texto: ", caractere1 , caractere2)