numero = int(input('digite um numero inteiro: '))
print(numero)