def LarguraeComprimento(a,b):
    area = a * b
    print('o valor da area é: ', area)

largura = int(input('Digite a largura: '))
comprimento = int(input('Digite a comprimento: '))
LarguraeComprimento(largura,comprimento)