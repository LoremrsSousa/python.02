def  escreva(txt):
    print('- ' * len(txt))
    print(txt)
    print('- ' * len(txt))
texto = str(input('digite um texto: '))
escreva(texto)
