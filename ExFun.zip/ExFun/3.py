def maior(valores):
    b = max(valores)
    print(f'O maior número é: {b}')

lista = []
while True:
    valor = input('Digite um número: ')
    lista.append(int(valor))  # Converte para inteiro antes de adicionar à lista

    res = input('Deseja continuar? (s/n): ')
    if res == 'n':
        break

print('O maior valor inserido foi:')
maior(lista)
